import { BrowserRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Train, MapPin, DollarSign, Armchair, MessageSquare, Menu, X, Home, LogIn } from "lucide-react";

// Pages
import HomePage from "./pages/Home";
import StationsPage from "./pages/Stations";
import TrainsPage from "./pages/Trains";
import FarePage from "./pages/Fare";
import SeatPlanPage from "./pages/SeatPlan";
import FeedbackPage from "./pages/Feedback";
import AdminLogin from "./pages/AdminLogin";
import AdminDashboard from "./pages/AdminDashboard";

function Sidebar() {
  const [isOpen, setIsOpen] = useState(true);
  const location = useLocation();

  const links = [
    { name: "Home", path: "/", icon: <Home size={20} /> },
    { name: "Stations", path: "/stations", icon: <MapPin size={20} /> },
    { name: "Trains", path: "/trains", icon: <Train size={20} /> },
    { name: "Fare", path: "/fare", icon: <DollarSign size={20} /> },
    { name: "Seat Plan", path: "/seat-plan", icon: <Armchair size={20} /> },
    { name: "Feedback", path: "/feedback", icon: <MessageSquare size={20} /> },
  ];

  const isAdmin = location.pathname.startsWith("/admin");

  if (isAdmin) return null;

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 left-4 z-50 p-2 bg-emerald-600 text-white rounded-md md:hidden"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      <motion.div
        initial={false}
        animate={{ width: isOpen ? 256 : 0 }}
        className="fixed top-0 left-0 h-full bg-emerald-900 text-white z-40 overflow-hidden shadow-xl"
      >
        <div className="p-6 w-64 flex flex-col h-full">
          <div className="flex items-center gap-3 mb-10">
            <Train size={32} className="text-emerald-400" />
            <h1 className="text-xl font-bold tracking-tight">BD Railway</h1>
          </div>

          <nav className="flex-1 space-y-2">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${
                  location.pathname === link.path
                    ? "bg-emerald-800 text-emerald-100"
                    : "hover:bg-emerald-800/50 text-emerald-200"
                }`}
              >
                {link.icon}
                <span className="font-medium">{link.name}</span>
              </Link>
            ))}
          </nav>

          <div className="mt-auto pt-6 border-t border-emerald-800">
            <Link
              to="/admin"
              className="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-emerald-800/50 text-emerald-200 transition-colors"
            >
              <LogIn size={20} />
              <span className="font-medium">Admin Login</span>
            </Link>
          </div>
        </div>
      </motion.div>
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}

function AppContent() {
  const location = useLocation();
  const isAdmin = location.pathname.startsWith("/admin");

  return (
    <div className="flex min-h-screen bg-slate-50 font-sans">
      <Sidebar />
      <main className={`flex-1 w-full ${isAdmin ? "" : "md:ml-64"}`}>
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <Routes location={location}>
              <Route path="/" element={<HomePage />} />
              <Route path="/stations" element={<StationsPage />} />
              <Route path="/trains" element={<TrainsPage />} />
              <Route path="/fare" element={<FarePage />} />
              <Route path="/seat-plan" element={<SeatPlanPage />} />
              <Route path="/feedback" element={<FeedbackPage />} />
              <Route path="/admin" element={<AdminLogin />} />
              <Route path="/admin/dashboard" element={<AdminDashboard />} />
            </Routes>
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
